
double spdot_(int *length,
              double *x,
              double *y,
              int *cols)
{
/*-------------------------------------------------------------
>>
>>  Compute the inner product of the dense vector y and
>>  the sparse vector x.  The vector x is actually in full
>>  storage, and the integer vector cols gives the actual
>>  indices in x that are to be multiplied times y.
>>
>>  Warning: since the indexing array cols is from a Fortran
>>  application, it assumes arrays are indexed from 1, not 0.
>>  That is why 1 is subtracted from cols[k] before it is used
>>  to index into x.
>>
>>     Randall Bramley
>>     Department of Computer Science
>>     Indiana University
>>     Phone: (812) 855-7790
>>     email: bramley@cs.indiana.edu
>>     Thu Sep 12 17:30:24 EST 1996
>>
-------------------------------------------------------------*/
  
     int k = 0;
     double alpha = 0.0;

     for (k = 0; k < *length; k++)
         alpha += y[k]*x[cols[k]-1];

     return alpha;
}
